package senCity;

import java.util.LinkedList;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.IOException;

public class Traces {
	
	private LinkedList<Trace> elmts;
	
	public Traces() {
		elmts = new LinkedList<>();
	}
	
	public void ajouter(Trace trace) {
		elmts.add(trace);
	}
	
	public int taille() {
		return elmts.size();
	}
	
	public String toString() {
		String txt = "Timestamp, SSID, Signal \n";
		for (Trace i : elmts) {
			txt += i.toString() + "\n";
		}
		
		return txt;
	}
	
	public void load(String nomFichier) throws IOException {
		File file;
		BufferedReader reader;
		Scanner scanner;
		String line, ts, ssid;
		int signal;
		
		try {	
			file = new File(nomFichier);
			reader = new BufferedReader(new FileReader(file));
		
			reader.readLine();
			line = reader.readLine();
			
			while (line != null) {
				scanner = new Scanner(line);
				scanner.useDelimiter(",");
				
				// We only get the info in the columns that interest us 
				ts = scanner.next();
				scanner.next();
				ssid = scanner.next();
				scanner.next(); scanner.next();
				signal = scanner.nextInt();
				
				this.ajouter(new Trace(ts, ssid, signal));
				
				scanner.close();
				line = reader.readLine();
			}
			reader.close();
			
		} catch (IOException e) {
			throw e;
		}
	}
	
	public void save(String nomFichier) throws IOException {
		BufferedWriter writer;
		
		File file = new File(nomFichier);

		if (file.exists())
			throw new IOException("le fichier existe d�j�");
		
		try {
			writer = new BufferedWriter(new FileWriter(file));
			
			writer.write("Timestamp, SSID, Signal");
			writer.newLine();
			
			for (Trace i : elmts) {
				writer.write(i.toString());
				writer.newLine();
			}
			
			writer.flush();
			writer.close();
			
		} catch (IOException e) {
			throw e;
		}
		
		
		
	}
	
	
	public static void main(String[] args) {
		Traces traces = new Traces();
		try {
			traces.load("src/senCity/capture_wifi.csv");
			//System.out.println(traces.toString());
			traces.save("src/senCity/output.txt");
		} catch(Exception e) {
			System.out.println(e);
		}
		
	}
}
