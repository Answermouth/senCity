package senCity;

public class Trace {
	private String ts, id;
	private int signal;

	public Trace(String timestamp, String ssid, int signalStrength) {
		ts = timestamp;
		id = ssid;
		signal = signalStrength;
	}
	
	public String toString() {
		return ts + "	" + id + "	" + signal;
	}
}
